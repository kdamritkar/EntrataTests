package Entrata;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class EntrataTests {
	public static void main(String[] args) {
    private WebDriver driver;

    @Before
    public void setUp() {
        // Set the path for the ChromeDriver
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    @Test
    public void testHomePageTitle() {
        driver.get("https://www.entrata.com");
        String title = driver.getTitle();
        Assert.assertEquals("Entrata", title);
    }

    @Test
    public void testLoginLinkExists() {
        driver.get("https://www.entrata.com");
        WebElement loginLink = driver.findElement(By.linkText("Login"));
        Assert.assertTrue("Login link should be present", loginLink.isDisplayed());
    }

    @Test
    public void testSearchFunctionality() {
        driver.get("https://www.entrata.com");
        WebElement searchBox = driver.findElement(By.name("search"));
        searchBox.sendKeys("apartments");
        searchBox.submit();

        String pageTitle = driver.getTitle();
        Assert.assertTrue("Page title should contain 'apartments'", pageTitle.contains("apartments"));
    }

    @Test
    public void testContactUsPage() {
        driver.get("https://www.entrata.com");
        WebElement contactUsLink = driver.findElement(By.linkText("Contact Us"));
        contactUsLink.click();

        String contactPageTitle = driver.getTitle();
        Assert.assertEquals("Contact Us | Entrata", contactPageTitle);
    }

    @After
    public void tearDown() {
        driver.quit();
    }
	}
}
